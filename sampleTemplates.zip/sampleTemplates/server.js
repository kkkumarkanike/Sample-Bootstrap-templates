var express = require('express');
var http = require('http');
var path = require('path');
var mongoose = require('mongoose');


var app = express();

app.set('port', 8000);
var index = require('./routes/login');
app.set('views', __dirname + '/views');
app.set('view engine', 'jade');

app.use(express.bodyParser());
app.use(express.methodOverride());
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));
mongoose.connect('mongodb://localhost/sampleDB');

var Schema = new mongoose.Schema({
    
    email:string,
    name: String
});

var user = mongoose.model('registered', Schema);

app.post('/register', function(req, res){
    
    new user({
        email: req.body.email,
        name : req.body.name
    }).save(function(err, doc){
        if(err)res.json(err);
        else res.send('success')
    });
});
var server = http.createServer(app).listen(app.get('port'), function(){
    console.log('port success'+app.get('port'));
});



